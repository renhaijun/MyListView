package com.example.mylistview;

import java.util.List;
import java.util.zip.Inflater;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MyAdapter extends BaseAdapter {
	private Context mContext;
	private List<Bean> mData;
	private Inflater mInflater;

	public MyAdapter() {
	}

	public MyAdapter(Context context, List<Bean> beans) {
		this.mContext = context;
		this.mData = beans;
	}

	@Override
	public int getCount() {
		return mData.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@SuppressLint("ViewHolder")
	@SuppressWarnings("static-access")
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		convertView = convertView.inflate(mContext, R.layout.item_listview, null);
		ViewHolder holder = null;
		Bean bean;
		if (holder == null) {
			holder = new ViewHolder();
			holder.titleText = (TextView) convertView.findViewById(R.id.tv_title);
			holder.descText = (TextView) convertView.findViewById(R.id.tv_desc);
			holder.dateText = (TextView) convertView.findViewById(R.id.tv_date);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		bean = mData.get(position);
		holder.titleText.setText(bean.getTitleStr());
		holder.descText.setText(bean.getDesStr());
		holder.dateText.setText(bean.getDateStr());
		return convertView;
	}

	private class ViewHolder {
		private TextView titleText;
		private TextView descText;
		private TextView dateText;
	}
}
