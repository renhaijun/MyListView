package com.example.mylistview;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class MainActivity extends Activity {

	private ListView mListView;
	private List<Bean> lists;
	private MyAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_layout);
		initView();
		initBean();
	}

	private void initBean() {
		lists = new ArrayList<Bean>();
		Bean mBean = null;
		for (int i = 0; i < 20; i++) {
			mBean = new Bean();
			mBean.setTitleStr("我的测试ListView" + i);
			mBean.setDateStr("2016-" + i);
			mBean.setDesStr("ListView测试" + i);
			lists.add(mBean);
		}
		initData();
	}

	private void initData() {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				if (adapter == null) {
					adapter = new MyAdapter(getApplicationContext(), lists);
					mListView.setAdapter(adapter);
				} else {
					adapter.notifyDataSetChanged();
				}
			}
		});
	}

	private void initView() {
		mListView = (ListView) findViewById(R.id.listView);
	}

}
